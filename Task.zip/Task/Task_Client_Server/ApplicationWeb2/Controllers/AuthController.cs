﻿using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Security.Cryptography;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Identity;
using Common;
using System.Linq;

namespace ApplicationWeb2.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class AuthController : ControllerBase
	{
		private static readonly ILogger consoleLogger;
		private static readonly PasswordHasher<Account> hasher;
		private static readonly Random rng;
		private const string USERS_FILE_NAME = "users.json";
		static AuthController()
		{
			rng = new Random(DateTime.Now.Millisecond);
			hasher = new PasswordHasher<Account>();
            consoleLogger = LoggerFactory.Create(logBuilder =>
            {
                logBuilder.AddConsole();
                logBuilder.AddDebug();
            }).CreateLogger<AuthController>();
        }

		[HttpPost("signup")]
		[Produces("application/json")]
		public IActionResult Register([FromBody] SignupRequest data)
		{
            AuthResponse response = new AuthResponse();
			if (Server.usersStorage.ContainsKey(data.Acc.Login)) 
			{
				response.ResponseCode = ApiErrCodes.LoginTaken;
				response.DefaultMessage = "Registered account with the same login already exists.";
			}
			else
			{
				if (Server.usersStorage.TryAdd(
					data.Acc.Login,
					(
						hasher.HashPassword(data.Acc, data.Acc.Password),
						new User(data.UserName)
					)
				))
				{
					response.ResponseCode = ApiErrCodes.Success;
					response.DefaultMessage = "OK";
					response.User = Server.usersStorage[data.Acc.Login].user;
			
					// update file which store users
					FileHelper.SaveToFileAsync(
						Path.Combine(Directory.GetCurrentDirectory(), USERS_FILE_NAME),
						Server.usersStorage
					);

					//create user message storage
					Server.CreateUserMsgStorage(response.User.UserName);
				}
				else
				{
					response.ResponseCode = ApiErrCodes.Unknown;
					response.DefaultMessage = "Unknown error. Possible registration problem";
				}
			}
			
			return Ok(response);
		}

		[HttpPost("login")]
		[Produces("application/json")]
		public IActionResult Login([FromBody] SignupRequest data)
		{
            AuthResponse response = new AuthResponse();

			if (Server.usersStorage.ContainsKey(data.Acc.Login)) // found registered user
			{
				response.ResponseCode = ApiErrCodes.PasswordIncorrect;
				response.DefaultMessage = "Incorrect password";
				if (hasher.VerifyHashedPassword(data.Acc, Server.usersStorage[data.Acc.Login].passHash, data.Acc.Password) == PasswordVerificationResult.Success) // password hash verified
				{
					response.ResponseCode = ApiErrCodes.Success;
					response.DefaultMessage = "OK";
					response.User = Server.usersStorage[data.Acc.Login].user;
					//check user storage, create if it does not exist
					Server.CreateUserMsgStorage(response.User.UserName);
				}
			}
			else 
			{
				response.ResponseCode = ApiErrCodes.LoginNotFound;
				response.DefaultMessage = "Account with this login does not exist.";
			}
			
			return Ok(response);
		}
	}
}
