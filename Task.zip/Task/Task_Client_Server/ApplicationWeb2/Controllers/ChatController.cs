﻿using System;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Common;

namespace ApplicationWeb2.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class ChatController : Controller
	{
		private static readonly ILogger consoleLogger;
		private static Message MessageToAllClients;
		static ChatController()
		{		
			consoleLogger = LoggerFactory.Create(logBuilder =>
			{
				logBuilder.AddConsole();
				logBuilder.AddDebug();
			}).CreateLogger<ChatController>();
			GenerateMessage();
		}

		public IActionResult Index()
		{
			return View(new Message());
		}


        [HttpGet("messages/{username}/{ts}")]
		[Produces("application/json")]
		public async Task<IActionResult> GetMessagesAfterTs(string username, DateTime ts)
		{
			if (string.IsNullOrWhiteSpace(username) || (!Server.CheckUserRegistration(username)))
				return Ok(new List<Message>());

			var messages = Server.LoadUserMessages(username).Where(msg => msg.Timestamp >= ts);
			return await Task.Run(() => Ok(new List<Message>(messages)));
		}

		[HttpGet("messages/{username}/{ts}")]
		[Produces("application/json")]
		public async Task<IActionResult> GetCountMessagesBeforeTs(string username, DateTime ts)
		{
			if (string.IsNullOrWhiteSpace(username) || (!Server.CheckUserRegistration(username))) 
				return Ok(new List<Message>());

			var messages=Server.LoadUserMessages(username).Where(msg =>msg.Timestamp <= ts);
			return await Task.Run(() => Ok(new List<Message>(messages)));
		}

		[HttpGet("messages/{username}")]
		[Produces("application/json")]
		public List<Message> GetMessages(string username)
		{
			if (string.IsNullOrWhiteSpace(username) || (!Server.CheckUserRegistration(username)))
				return new List<Message>(); 
			return new List<Message>() { MessageToAllClients };
		}
			
		[HttpPost("messages")]
		[Produces("application/json")]
		public IActionResult PostMessage([FromBody] Message msg)
		{
			consoleLogger.LogInformation($"Received message from user({msg.FromUserName}): {msg.Content}");
			AuthResponse response = new AuthResponse();
			response.ResponseCode = ApiErrCodes.Unknown;
			
			if (!Server.CheckUserRegistration(msg.FromUserName)) 
			{
				response.ResponseCode = ApiErrCodes.LoginNotFound;
				response.DefaultMessage = "Message sender is not a registered User";
				return Ok(response);
			}
			//save the message into the message file of the user on server side
			Server.SaveUserMessages(msg.FromUserName, msg);
            response.ResponseCode = ApiErrCodes.Success;
            response.DefaultMessage = "OK";
            response.User = new User(msg.FromUserName);
            return Ok(response);
		}

		[NonAction]
		private  static void GenerateMessage()
        {
			MessageToAllClients = new Message() { Content = "Server message " + new Random().Next(1, 1000), Timestamp = DateTime.Now, FromUserName = "Server" };
		}
	}
}
