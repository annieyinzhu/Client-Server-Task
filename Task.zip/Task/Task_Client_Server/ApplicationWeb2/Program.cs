using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Common;

namespace ApplicationWeb2
{
	public class Server
	{
		private const string CONFIG_FILE_NAME = "config.json";
		private const string USERS_FILE_NAME = "users.json";
		private const string MESSAGES_FILE_NAME = "messages.json";

		internal static ServerConfig config;
		internal static Dictionary<string, (string passHash, User user)> usersStorage;
		internal static List<User> UsersList
		{
			get => new List<(string, User)>(usersStorage.Values)
				.ConvertAll(i => i.Item2);
		}

		private static readonly ILogger consoleLogger = LoggerFactory.Create(builder =>
		{
			builder.AddConsole();
			builder.AddDebug();
		}).CreateLogger<Server>();

		public static void Main(string[] args)
		{
			try
			{
				LoadConfig();
				LoadUsers(Path.Combine(Directory.GetCurrentDirectory(), USERS_FILE_NAME));

				Directory.CreateDirectory(Path.Combine(Directory.GetCurrentDirectory(), "MessagesStorage"));
				foreach (string username in UsersList.Select(user =>user.UserName))
				{
					CreateUserMsgStorage(username);
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine(Environment.NewLine + "Press Enter to close this window...");
				Console.ReadLine();
				return;
			}

			CreateHostBuilder(args).Build().Run();

			Console.WriteLine(Environment.NewLine + "Press Enter to close this window...");
			Console.ReadLine();

			return;
		}

		internal static bool CheckUserRegistration(string name)
		{
			return UsersList.Select(user => user.UserName).Contains(name);
		}

		internal static void CreateUserMsgStorage(string username)
        {
			string messagesFolderPath = Path.Combine(Directory.GetCurrentDirectory(), "MessagesStorage", $"{username}");
			Directory.CreateDirectory(messagesFolderPath);
			if (!File.Exists(Path.Combine(messagesFolderPath, MESSAGES_FILE_NAME)))
			{
				FileHelper.SaveToFile(Path.Combine(messagesFolderPath, MESSAGES_FILE_NAME), new List<Message>());
			}
		}
		internal static void SaveUserMessages(string username, Message msg)
        {
			if (string.IsNullOrWhiteSpace(username) || msg == null)
				return;
			var msgs = LoadUserMessages(username);
			msgs.Add(msg);
			var path = Path.Combine(Directory.GetCurrentDirectory(), "MessagesStorage", username, "messages.json");
			FileHelper.SaveToFile(path, msgs);
		}

		internal static List<Message> LoadUserMessages(string username)
		{
			var path = Path.Combine(Directory.GetCurrentDirectory(), "MessagesStorage", username, "messages.json");
			if (File.Exists(path))
			{
				return FileHelper.LoadFromFile<List<Message>>(
					path
				);
			}
			else
			{
				return new List<Message>();
			}
		}

		private static void LoadUsers(string path)
		{
			if (File.Exists(path))
			{
				usersStorage = FileHelper.LoadFromFile<Dictionary<string, (string, User)>>(path);
			}
			else
			{
				usersStorage = new Dictionary<string, (string, User)>();
			}
		}
		private static void LoadConfig()
		{
			if (File.Exists(Path.Combine(Directory.GetCurrentDirectory(), CONFIG_FILE_NAME)))
			{
				config = FileHelper.LoadFromFile<ServerConfig>(
					Path.Combine(Directory.GetCurrentDirectory(),
					CONFIG_FILE_NAME)
				);
			}
			else
			{
				config = new ServerConfig() 
				{
					Port = "8080",
					StoredMessagesLimit = 50
				};
				FileHelper.SaveToFile(
					Path.Combine(Directory.GetCurrentDirectory(), CONFIG_FILE_NAME),
					config
				);
			}
		}

		public static IHostBuilder CreateHostBuilder(string[] args) =>
			Host.CreateDefaultBuilder(args)
				.ConfigureWebHostDefaults(webBuilder =>
				{
					webBuilder
						.UseKestrel()
						.UseContentRoot(Directory.GetCurrentDirectory())
						.UseUrls(
							$"http://0.0.0.0:{config.Port}"
						)
						.UseStartup<Startup>();
				});
	}
}
