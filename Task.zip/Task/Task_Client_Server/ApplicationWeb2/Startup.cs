using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using System.IO;
using System.Collections.Generic;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Common;

namespace ApplicationWeb2
{
	public class Startup
	{
		private ILogger consoleLogger = LoggerFactory.Create(builder =>
		{
			builder.AddConsole();
			builder.AddDebug();
		}).CreateLogger<Startup>();


		public void ConfigureServices(IServiceCollection services)
		{
			services.AddCors();
			services.AddControllers();
			services.AddMvc();
			services.AddMvcCore();
			
			services.AddControllersWithViews();
			services.AddHttpClient();
		}

		public void Configure(IApplicationBuilder app, IWebHostEnvironment env, IHostApplicationLifetime lifetime)
		{
			if (env.IsDevelopment())
			{
				app.UseDeveloperExceptionPage();
			}

			lifetime.ApplicationStopping.Register(() =>
			{
				foreach (var pair in Server.usersStorage)
				{
					string messagesFilePath = Path.Combine(Directory.GetCurrentDirectory(), "MessagesStorage", pair.Value.user.UserName, "messages.json");

					// create file with empty list if not exists
					if (!File.Exists(Path.Combine(messagesFilePath)))
					{
						FileHelper.SaveToFile(Path.Combine(messagesFilePath), new List<Message>());
					}
				}
			});


			app.UseRouting();

			app.UseAuthorization();

            app.UseCors(builder =>
            {
                builder.AllowAnyOrigin();
            });

			app.UseEndpoints(endpoints =>
			{
				endpoints.MapControllers();
			});

			app.Run(async context =>
			{
				context.Response.StatusCode = StatusCodes.Status404NotFound;
				await context.Response.WriteAsync("<h1>404 Not Found</h1>");
			});
		}
	}
}
