﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using Application1.ViewModels;
using System.Linq;
using Common;
using System.Windows.Threading;

namespace Application1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
		private const string CLIENT_CONFIG_FILE_NAME = "config.json";
		private ClientConfig configInfo;
		private User currentUser;
		private string currentToken;

		private List<Message> historicalMessages = new List<Message>();
		public static readonly DependencyProperty MainWindowModelProperty =
            DependencyProperty.Register("MainWindowModel", typeof(MainWindowViewModel),
            typeof(MainWindow), new PropertyMetadata(default(MainWindowViewModel)));

        public MainWindowViewModel MainWindowModel
        {
            get { return (MainWindowViewModel)GetValue(MainWindowModelProperty); }
            set { SetValue(MainWindowModelProperty, value); }
        }
        public MainWindow()
        {
            InitializeComponent();
			MainWindowModel = new MainWindowViewModel() 
			{ 
               LoginViewModel = new LoginViewModel(),
			   SignUpViewModel = new SignUpViewModel()
			}; 
        }
	}
}
