﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace Application1.Converter
{
    public class BoolToVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter,CultureInfo culture)
        {
            var visible = (bool)value;
            var result = visible ? Visibility.Visible : Visibility.Collapsed;

            return result;

        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new InvalidOperationException("ConvertBack is not supported for BoolToVisibilityConverter.");
        }
    }
}
