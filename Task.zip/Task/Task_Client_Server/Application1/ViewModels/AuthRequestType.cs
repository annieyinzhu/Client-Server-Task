﻿

namespace Application1.ViewModels
{
	public enum AuthRequestType
	{
		Login,
		Signup
	};
}
