﻿using System;
using Common;
using System.Threading.Tasks;
using System.Windows;
using System.IO;
using System.Text.Json;

namespace Application1.ViewModels
{
    public class LoginViewModel : UserViewModelBase
    {
        private const string CLIENT_CONFIG_FILE_NAME = "config.json";
        public LoginViewModel():base()
        {
            ClientConfig = InitializeLoginClientConfig();
        }
        protected override bool CanConnect()
        {
            return true;
            return ClientConfig != null && (!string.IsNullOrWhiteSpace(ClientConfig.UserName))
                && (!string.IsNullOrWhiteSpace(ClientConfig.Password));
        }
        protected override async void Connect()
        {
            try
            {
                await Task.Run(() =>
                {
                    AuthResponse response = AuthRequest(AuthRequestType.Login, ClientConfig);
                    switch (response.ResponseCode)
                    {
                        case ApiErrCodes.Success:
                            Connected = true;
                            ResponseText = "Log in successful";
                            CurrentUser = response.User;
                            ServerMessagesRequesting();
                            return;
                        case ApiErrCodes.LoginNotFound:
                            ResponseText = "Log in not found";
                            return;
                        case ApiErrCodes.PasswordIncorrect:
                            ResponseText = response.DefaultMessage;
                            return;
                        case ApiErrCodes.NoConnection:
                            ResponseText = "No connection to server";
                            return;
                        case ApiErrCodes.Unknown:
                            ResponseText = "Unkown error occured";
                            return;
                        default:
                            break;
                    }
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private ClientConfig InitializeLoginClientConfig()
        {
            ClientConfig configInfo = null;
            try
            {
                configInfo = JsonSerializer.Deserialize<ClientConfig>(File.ReadAllText(Path.Combine(Directory.GetCurrentDirectory(), CLIENT_CONFIG_FILE_NAME)));
                if (configInfo.MessageRequestTime < 50U)
                    configInfo.MessageRequestTime = 200U;
            }
            catch
            {
                configInfo = CreateDefaultConfig();
                FileHelper.SaveToFile(Path.Combine(Directory.GetCurrentDirectory(), CLIENT_CONFIG_FILE_NAME), configInfo);
            }
            return configInfo;
        }
    }
}
