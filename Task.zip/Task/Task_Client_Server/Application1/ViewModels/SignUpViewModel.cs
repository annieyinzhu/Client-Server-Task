﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using Common;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace Application1.ViewModels
{
    public class SignUpViewModel : UserViewModelBase
    {
        public SignUpViewModel():base()
        {
            ClientConfig = CreateDefaultConfig();
        }
        protected override bool CanConnect()
        {
            return true;
            return ClientConfig != null && (!string.IsNullOrWhiteSpace(ClientConfig.UserName))
                && (!string.IsNullOrWhiteSpace(ClientConfig.Password));
        }

        protected override async void Connect()
        {
            try
            {
                await Task.Run(() =>
                {
                    if (string.IsNullOrWhiteSpace(ClientConfig.UserName))
                    {
                        MessageBox.Show("Empty username");
                    }
                    AuthResponse response = AuthRequest(AuthRequestType.Signup, ClientConfig);
                    switch (response.ResponseCode)
                    {
                        case ApiErrCodes.Success:
                            ResponseText = "Sign up successful";
                            CurrentUser = response.User;
                            //after signup, do log in 
                            var loginResponse = AuthRequest(AuthRequestType.Login, ClientConfig);
                            if (loginResponse.ResponseCode == ApiErrCodes.Success)
                            {
                                Connected = true;
                                ResponseText = "Login successful";
                                CurrentUser = response.User;
                                ServerMessagesRequesting();
                            }
                            
                            return;
                        case ApiErrCodes.LoginTaken:
                            ResponseText = "Entered login is already taken";
                            return;
                        case ApiErrCodes.NoConnection:
                            ResponseText = "No connection to server";
                            return;
                        case ApiErrCodes.Unknown:
                            ResponseText = "Unkown error occured";
                            return;
                        default:
                            break;
                    }
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
