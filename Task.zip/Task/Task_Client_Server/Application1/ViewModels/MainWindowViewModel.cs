﻿using System.ComponentModel;
using Common;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows;
namespace Application1.ViewModels
{
    public class MainWindowViewModel : INotifyPropertyChanged
    {
        private LoginViewModel loginViewModel;
        private SignUpViewModel signUpViewModel;
        private bool showSignupView = false;
        private ICommand cmdSend;
        private string sendMessageContent;
  
        public MainWindowViewModel()
        {
            cmdSend = new DelegateCommand(obj => SendExe(),
                        obj => SendCanExe());
        }

        public ICommand CmdSend
        {
            get { return cmdSend; }
        }
        public bool ShowSignupView
        {
            get { return showSignupView; }
            set
            {
                showSignupView = value;
                OnPropertyChanged(nameof(ShowSignupView));
            }
        }

        public LoginViewModel LoginViewModel
        {
            get { return loginViewModel; }
            set {
                loginViewModel = value;
                OnPropertyChanged(nameof(LoginViewModel));
            }
        }
        public SignUpViewModel SignUpViewModel
        {
            get { return signUpViewModel; }
            set
            {
                signUpViewModel = value;
                OnPropertyChanged(nameof(SignUpViewModel));
            }
        }

        public ClientConfig ClientConfig
        {
            get
            {
                if(!string.IsNullOrWhiteSpace(LoginViewModel?.ClientConfig?.UserName))
                {
                    return LoginViewModel.ClientConfig;
                }
                return SignUpViewModel.ClientConfig;
            }
        }
        public string SendMessageContent
        {
            get { return sendMessageContent; }
            set
            {
                sendMessageContent = value;
                OnPropertyChanged(nameof(SendMessageContent));
            }
        }
        public bool SendCanExe()
        {
            return true;
            return !string.IsNullOrWhiteSpace(SendMessageContent);
        }

        public async void SendExe()
        {
            try
            {
                Message mes = new Message()
                {
                    Content = SendMessageContent,
                    Timestamp = DateTime.Now,
                    FromUserName = ClientConfig.UserName,
                };
                SendMessageContent = string.Empty;
                await Task.Run(() => RequestHelper.ServerRequest<AuthResponse>($"{ClientConfig.ServerAddress}/api/chat/messages", mes));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            var handler = PropertyChanged;
            if (handler != null)
                handler(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}