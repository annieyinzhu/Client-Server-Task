﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using Common;
using System.Windows.Input;

namespace Application1.ViewModels
{
    public class UserViewModelBase : INotifyPropertyChanged
    {
        private ClientConfig clientConfig;
        private string responseText;
        private Message latestReceivedMessage;
        internal User CurrentUser  { get;  set; }
        private ICommand cmdConnect;

        public UserViewModelBase(){
            cmdConnect = new DelegateCommand(obj => ConnectExe(),
                obj => ConnectCanExe());
         }

        public ICommand CmdConnect
        {
            get { return cmdConnect; }
        }


        public Message LatestReceivedMessage
        {
            get { return latestReceivedMessage; }
            set
            {
                latestReceivedMessage = value;
                OnPropertyChanged(nameof(LatestReceivedMessage));
            }
        }

        public ClientConfig ClientConfig
        {
            get { return clientConfig; }
            set
            {
                clientConfig = value;
                OnPropertyChanged(nameof(ClientConfig));
            }
        }
        public string ResponseText
        {
            get { return responseText; }
            set
            {
                responseText = value;
                OnPropertyChanged(nameof(ResponseText));
            }
        }
        public bool Connected { get; protected set; } = false;
        public bool ConnectCanExe()
        {
            return CanConnect();
        }

        public async void ConnectExe()
        {
            Connect();
        }

        protected virtual bool CanConnect()
        {
            return true;
        }

        protected virtual async void Connect()
        {

        }

        public AuthResponse AuthRequest(AuthRequestType type, ClientConfig clientConfig)
        {
            var newAccount = new SignupRequest()
            {
                UserName = clientConfig.UserName,
                Acc = new Account()
                {
                    Login = clientConfig.UserName,
                    Password = clientConfig.Password
                }
            };
            AuthResponse response;
            try
            {
                response = RequestHelper.ServerRequest<AuthResponse>($"{clientConfig.ServerAddress}/api/auth/{type}", newAccount);
                if (response.ResponseCode == ApiErrCodes.Success)
                {
                    CurrentUser = response.User;
                }
            }
            catch
            {
                response = new AuthResponse()
                {
                    ResponseCode = ApiErrCodes.NoConnection
                };
            }
            return response;
        }
        protected ClientConfig CreateDefaultConfig()
        {
            return new ClientConfig()
            {
                MessageRequestTime = 200U,
                ServerAddress = "http://localhost:8080",
                UserName = "",
                Password = ""
            };
        }

        protected virtual async void ServerMessagesRequesting()
        {
            int reconectionCount = 3;
            for (int i = 0; i < reconectionCount; i++)
            {
                await Task.Run(() =>
                {
                    while (true)
                    {
                        try
                        {
                            RequestServerMessage();
                            Task.Delay((int)ClientConfig.MessageRequestTime);
                        }
                        catch (Exception ex)
                        {
                            if (i < reconectionCount - 1) break;
                            break;
                        }
                    }
                });
            }
        }

        private void RequestServerMessage()
        {
            var recivedMessages = RequestHelper.ServerRequest<List<Message>>($"{ClientConfig.ServerAddress}/api/chat/messages/{ClientConfig.UserName}/", null, "GET");

            if (recivedMessages.Count != 0)
            {
                Application.Current.Dispatcher.BeginInvoke(
                  DispatcherPriority.Background,
                  new Action(() => {
                      LatestReceivedMessage = recivedMessages.LastOrDefault();
                  }));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            var handler = PropertyChanged;
            if (handler != null)
                handler(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
