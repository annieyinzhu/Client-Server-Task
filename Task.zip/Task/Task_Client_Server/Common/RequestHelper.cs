﻿using Newtonsoft.Json;
using System.IO;
using System.Net;

namespace Common
{
	public static class RequestHelper
	{
        public static TResponse ServerRequest<TResponse>(string url, object body = null, string method = "POST")
		{
			HttpWebRequest webRequest = WebRequest.CreateHttp(url);
			webRequest.Method = method;
			webRequest.ContentType = "application/json";
			if (body != null) using (StreamWriter writer = new StreamWriter(webRequest.GetRequestStream()))
			{
				writer.Write(JsonConvert.SerializeObject(body));
			}
			HttpWebResponse webResponse = webRequest?.GetResponse() as HttpWebResponse;
			using (StreamReader reader = new StreamReader(webResponse?.GetResponseStream()))
			{
				var stringContent = reader.ReadToEnd();
				var msgs = JsonConvert.DeserializeObject<TResponse>(stringContent);
				return msgs;
			}
		}
	}
}
