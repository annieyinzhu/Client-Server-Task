﻿namespace Common
{
	public struct ServerConfig
	{
		public string Port { get; set; }
		public int StoredMessagesLimit { get; set; }
	}
}
