﻿using System.IO;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using Newtonsoft.Json;

namespace Common
{
	public static class FileHelper
	{
		public static void SaveToFile(string path, object item, Formatting options = Formatting.Indented)
		{
			File.WriteAllText(path, JsonConvert.SerializeObject(item, options));
		}

		public static TItem LoadFromFile<TItem>(string path, JsonSerializerSettings settings = null)
		{
			return JsonConvert.DeserializeObject<TItem>(File.ReadAllText(path), settings);
		}

		public static TItem LoadFromFileIfExists<TItem>(string path, JsonSerializerSettings settings = null)
		{
			return File.Exists(path) ? FileHelper.LoadFromFile<TItem>(path, settings) : default(TItem);
		}

		public static async void SaveToFileAsync(string path, object item, Formatting options = Formatting.Indented)
		{
			await Task.Run(() => File.WriteAllTextAsync(path, JsonConvert.SerializeObject(item, options)));
		}
	}
}
