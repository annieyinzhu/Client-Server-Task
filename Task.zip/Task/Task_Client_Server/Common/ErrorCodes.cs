﻿namespace Common
{
	public enum ApiErrCodes
	{
		Success = 0,
		LoginTaken,
		LoginNotFound,
		PasswordIncorrect,
		NoConnection,
		Unknown
	}
}
