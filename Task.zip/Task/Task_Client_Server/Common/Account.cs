﻿namespace Common
{
	public class Account
	{
		public string Login { get; set; }
		public string Password { get; set; }
		public Account() { }
		public Account(string fullName)
		{
		    Login = fullName.Split(':', 2)[0];
			Password = fullName.Split(':', 2)[1];
		}
		public override string ToString() => $"{Login}:{Password}";
	}
}
