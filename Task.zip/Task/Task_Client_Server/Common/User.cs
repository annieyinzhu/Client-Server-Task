﻿using System;
using System.Collections.Generic;

namespace Common
{
	[Serializable]
	public class User
	{
		public string UserName { get; set; }
		public User() {  }
		public User(string userName) 
		{
			UserName = userName;
		}

		public static bool operator ==(User user1, User user2) =>
			(user1?.UserName == user2?.UserName) ;
		public static bool operator !=(User user1, User user2) =>
			(user1?.UserName != user2?.UserName);
	}
}
