﻿using System;

namespace Common
{
	[Serializable]
	public class ClientConfig

	{
		public uint MessageRequestTime { get; set; }
		public string ServerAddress { get; set; }
		public string UserName { get; set; }
		public string Password { get; set; }

		public static bool operator ==(ClientConfig user1, ClientConfig user2)
		{
			return ((user1?.MessageRequestTime == user2?.MessageRequestTime)
				&& (user1?.ServerAddress == user2?.ServerAddress)
				&& (user1?.UserName == user2?.UserName)
				&& (user1?.Password == user2?.Password));
		}

		public static bool operator !=(ClientConfig user1, ClientConfig user2)
		{
			return ((user1?.MessageRequestTime != user2?.MessageRequestTime)
				|| (user1?.ServerAddress != user2?.ServerAddress)
				|| (user1?.UserName != user2?.UserName)
				|| (user1?.Password != user2?.Password));
		}
	}
}
