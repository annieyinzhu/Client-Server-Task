﻿using System;
namespace Common
{
	public class AuthResponse
	{
		public ApiErrCodes ResponseCode { get; set; }
		public string DefaultMessage { get; set; }
		public User User { get; set; }
	}
}
