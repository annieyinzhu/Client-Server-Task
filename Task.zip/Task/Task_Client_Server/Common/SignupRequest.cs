﻿
namespace Common
{
	public class SignupRequest
	{
		public Account Acc { get; set; }
		public string UserName { get; set; }
	}
}
