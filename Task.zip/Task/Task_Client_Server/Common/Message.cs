﻿using System;

namespace Common
{
	[Serializable]
	public class Message
	{
		public string Content { get; set; }
		public DateTime Timestamp { get; set; }
		public string FromUserName { get; set; }
        public override string ToString() => $"[{Timestamp.ToLongTimeString()}] {FromUserName} : {Content}";
    }

	public delegate void MessageEventHandler();

	public class MessageEventArgs
	{
		public int TotalMessagesCount { get; set; }
	}
}
